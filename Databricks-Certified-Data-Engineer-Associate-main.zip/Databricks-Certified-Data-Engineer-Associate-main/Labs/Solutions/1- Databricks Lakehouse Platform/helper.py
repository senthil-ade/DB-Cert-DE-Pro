# Databricks notebook source
my_country = "France"

# COMMAND ----------

def addition(a, b):
    print(a + b)
